#include "LoginWindow.h"
#include "StyleHelper.h"
#include "database/DatabaseManager.h"
#include <QGraphicsDropShadowEffect>

LoginWindow::LoginWindow(QWidget *parent) : QWidget(parent) {
    setWindowTitle("Fail{First} - Login");
    resize(400, 600);
    setStyleSheet("background-color: #0f172a;"); // Dark Window
    
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setAlignment(Qt::AlignCenter);
    
    QFrame *card = new QFrame;
    card->setFixedSize(360, 500);
    card->setStyleSheet("background-color: #1e293b; border-radius: 20px; border: 1px solid #334155;"); // Dark Card
    
    QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect;
    shadow->setBlurRadius(40);
    shadow->setColor(QColor(0,0,0,20));
    shadow->setOffset(0, 10);
    card->setGraphicsEffect(shadow);
    
    QVBoxLayout *layout = new QVBoxLayout(card);
    layout->setSpacing(20);
    layout->setContentsMargins(30, 40, 30, 40);
    
    // Title
    QLabel *title = new QLabel("Fail First");
    title->setStyleSheet("font-family: 'Inter'; font-size: 36px; font-weight: 900; color: #818cf8;"); // Indigo-400
    title->setAlignment(Qt::AlignCenter);
    
    // Subtitle / Tagline Box
    QLabel *subtitle = new QLabel("Master Programming\nThrough Debugging");
    subtitle->setWordWrap(true);
    subtitle->setAlignment(Qt::AlignCenter);
    subtitle->setStyleSheet("font-family: 'Inter'; font-size: 16px; color: #94a3b8; border: 1px solid #334155; border-radius: 10px; padding: 10px;");
    
    // Username Section
    QLabel *userLbl = new QLabel("Username");
    userLbl->setStyleSheet("font-family: 'Inter'; font-size: 16px; font-weight: bold; color: #e2e8f0; margin-bottom: 5px;");
    
    m_userEdit = new QLineEdit;
    m_userEdit->setPlaceholderText("Enter your username");
    m_userEdit->setStyleSheet("QLineEdit { padding: 15px; border: 2px solid #818cf8; border-radius: 10px; font-size: 16px; background: #111827; color: #f3f4f6; } QLineEdit:focus { border-color: #6366f1; }");
    
    // Spacer for visual separation (no password field per request "just want the username to Get Started")
    // User said: "just want the username to Get Started or create account ... get started means login"
    // So removing password field? "login system on it for saving the user data by unique username"
    // I'll keep it simple: Username only for now if that's what "just want the username" means, 
    // OR keep password but hide it? "Just want the username" implies simple auth.
    // I will remove logic for password checking in the next step or autofill dummy password.
    // Let's stick to the mockup: It only shows "Username" input.
    
    QPushButton *startBtn = new QPushButton("Start Debugging");
    startBtn->setStyleSheet("QPushButton { background-color: #6366f1; color: white; border-radius: 10px; padding: 15px; font-size: 18px; font-weight: bold; } QPushButton:hover { background-color: #4f46e5; }");
    startBtn->setCursor(Qt::PointingHandCursor);
    connect(startBtn, &QPushButton::clicked, this, &LoginWindow::onSignInClicked);
    
    QPushButton *createBtn = new QPushButton("Create Account");
    createBtn->setStyleSheet("QPushButton { background-color: transparent; color: #94a3b8; border: 1px solid #334155; border-radius: 10px; padding: 15px; font-size: 16px; font-weight: bold; } QPushButton:hover { background-color: #1e293b; color: #e2e8f0; }");
    createBtn->setCursor(Qt::PointingHandCursor);
    connect(createBtn, &QPushButton::clicked, this, &LoginWindow::onSignUpClicked);
    
    m_statusLbl = new QLabel("");
    m_statusLbl->setStyleSheet("color: #ef4444; font-size: 14px;");
    m_statusLbl->setAlignment(Qt::AlignCenter);
    
    layout->addWidget(title);
    layout->addWidget(subtitle);
    layout->addSpacing(20);
    layout->addWidget(userLbl);
    layout->addWidget(m_userEdit);
    layout->addWidget(m_statusLbl);
    layout->addSpacing(10);
    layout->addWidget(startBtn);
    layout->addWidget(createBtn);
    layout->addStretch();
    
    mainLayout->addWidget(card);
}

void LoginWindow::onSignInClicked() {
    QString user = m_userEdit->text();
    // Default password for simple username-only auth flow
    QString pass = "default_pass"; 
    
    if (user.isEmpty()) {
        m_statusLbl->setText("Please enter a username.");
        return;
    }
    
    if (DatabaseManager::instance().login(user, pass)) {
        emit loginSuccess();
    } else {
        m_statusLbl->setText("User not found. Create an account?");
    }
}

void LoginWindow::onSignUpClicked() {
    QString user = m_userEdit->text();
    QString pass = "default_pass";
    
    if (user.isEmpty()) {
        m_statusLbl->setText("Enter a username to create account.");
        return;
    }
    
    if (DatabaseManager::instance().registerUser(user, pass)) {
        emit loginSuccess();
    } else {
        m_statusLbl->setText("Username already taken.");
    }
}
