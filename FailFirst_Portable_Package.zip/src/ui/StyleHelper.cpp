#include "StyleHelper.h"

// Palette: Modern Dark (Slate)
// Background: #0f172a (Slate 900)
// Sidebar/Cards: #1e293b (Slate 800)
// Text: #e2e8f0 (Slate 200) / #94a3b8 (Slate 400)
// Accent: #6366f1 (Indigo 500)
// Story Headers: #a78bfa (Purple 400)
// Story Body: #86efac (Green 300)

QString StyleHelper::getLabelStyle(const QString &type) {
    if (type == "header") {
        return "font-family: 'Inter', sans-serif; font-size: 28px; font-weight: 800; color: #f1f5f9; margin-bottom: 20px;"; // Slate-100
    } else if (type == "body") {
        return "font-family: 'Inter', sans-serif; font-size: 16px; color: #cbd5e1; line-height: 1.6;"; // Slate-300
    } else if (type == "muted") {
         return "color: #64748b; font-size: 14px;";
    }
    return "";
}

QString StyleHelper::getButtonStyle(const QString &type) {
    if (type == "primary") {
        return "QPushButton { "
               "  background-color: #6366f1; " // Indigo-500
               "  color: white; "
               "  border-radius: 8px; "
               "  padding: 10px 20px; "
               "  font-weight: bold; "
               "  font-size: 14px; "
               "} "
               "QPushButton:hover { background-color: #4f46e5; } " // Indigo-600
               "QPushButton:pressed { background-color: #4338ca; }";
    } else if (type == "success") {
        return "QPushButton { "
               "  background-color: #10b981; " // Emerald-500
               "  color: white; "
               "  border-radius: 8px; "
               "  padding: 10px 20px; "
               "  font-weight: bold; "
               "} "
               "QPushButton:hover { background-color: #059669; }";
    } else if (type == "danger") {
        return "QPushButton { "
               "  background-color: #ef4444; " // Red-500
               "  color: white; "
               "  border-radius: 8px; "
               "  padding: 10px 20px; "
               "  font-weight: bold; "
               "} "
               "QPushButton:hover { background-color: #dc2626; }";
    }
    return "";
}

QString StyleHelper::getMainWindowStyle() {
    return "QMainWindow { background-color: #0f172a; }"; // Deep Slate Dark
}

QString StyleHelper::getSidebarStyle() {
    return "QListWidget { "
           "  background-color: transparent; "
           "  border: none; "
           "  outline: none; "
           "  font-size: 16px; "
           "} "
           "QListWidget::item { "
           "  padding: 15px 20px; "
           "  color: #94a3b8; " // Slate-400
           "  border-radius: 8px; "
           "  margin: 5px 10px; "
           "} "
           "QListWidget::item:selected { "
           "  background-color: #334155; " // Slate-700
           "  color: #818cf8; " // Indigo-400
           "  font-weight: bold; "
           "} "
           "QListWidget::item:hover { "
           "  background-color: #1e293b; " // Slate-800
           "}";
}

QString StyleHelper::getCodeEditorStyle() {
    return "QPlainTextEdit { "
           "  background-color: #111827; " // Gray-900 (Darker than bg)
           "  color: #f3f4f6; "
           "  font-family: 'JetBrains Mono', monospace; "
           "  font-size: 14px; "
           "  border: 1px solid #374151; "
           "  border-radius: 8px; "
           "  padding: 10px; "
           "  selection-background-color: #3b82f6; "
           "}";
}

QString StyleHelper::getCardStyle() {
    return "QFrame { "
           "  background-color: #1e293b; " // Slate-800
           "  border: 1px solid #334155; " // Slate-700
           "  border-radius: 12px; "
           "}";
}

QString StyleHelper::getQuizOptionStyle() {
    return "QRadioButton { "
           "  background-color: #1e293b; " // Slate-800
           "  border: 2px solid #334155; " // Slate-700
           "  border-radius: 12px; "
           "  padding: 15px; "
           "  color: #e2e8f0; " // Slate-200
           "  font-size: 16px; "
           "  font-weight: bold; "
           "} "
           "QRadioButton::indicator { width: 0px; height: 0px; } "
           "QRadioButton:checked { "
           "  background-color: #312e81; " // Indigo-900
           "  border: 2px solid #818cf8; " // Indigo-400
           "  color: #818cf8; "
           "} "
           "QRadioButton:hover { "
           "  border: 2px solid #64748b; "
           "}";
}

QString StyleHelper::getStoryDocumentCSS() {
    return "h1, h2, h3 { "
           "  color: #a78bfa; " // Light Purple (Purple-400)
           "  font-family: 'Inter', sans-serif; "
           "  font-weight: 800; "
           "  margin-bottom: 10px; "
           "} "
           "p, li { "
           "  color: #86efac; " // Light Green (Green-300)
           "  font-family: 'Inter', sans-serif; "
           "  font-size: 18px; "
           "  line-height: 1.6; "
           "} "
           "code { "
           "  font-family: 'JetBrains Mono', monospace; "
           "  background-color: #374151; " // Gray-700
           "  color: #f0abfc; " // Fuchsia-300
           "  padding: 2px 4px; "
           "  border-radius: 4px; "
           "} "
           "pre { "
           "  background-color: #111827; " // Gray-900
           "  color: #e5e7eb; "
           "  padding: 15px; "
           "  border: 1px solid #374151; "
           "  border-radius: 8px; "
           "  margin: 20px 0; "
           "  font-family: 'JetBrains Mono', monospace; "
           "}";
}
