#include "LearnSection.h"
#include "StyleHelper.h"

#include "AnimationHelper.h"
#include <QScrollArea>
#include <QPainter>
#include <QTimer>

LearnSection::LearnSection(QWidget *parent) : QWidget(parent) {
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(0, 0, 0, 0);

    QScrollArea *scroll = new QScrollArea;
    scroll->setWidgetResizable(true);
    scroll->setStyleSheet("background-color: #0f172a; border: none;"); // Dark Background
    
    QWidget *container = new QWidget;
    m_scrollLayout = new QVBoxLayout(container);
    m_scrollLayout->setSpacing(60);
    m_scrollLayout->setAlignment(Qt::AlignHCenter); // Center path
    m_scrollLayout->setContentsMargins(0, 50, 0, 50);

    scroll->setWidget(container);
    mainLayout->addWidget(scroll);

    refresh();
}

void LearnSection::refresh() {
    clearLayout();
    renderPath();
}

void LearnSection::clearLayout() {
    QLayoutItem *child;
    while ((child = m_scrollLayout->takeAt(0)) != nullptr) {
        delete child->widget();
        delete child;
    }
}

void LearnSection::renderPath() {
    QList<Challenge> challenges = DatabaseManager::instance().getAllChallenges();
    int currentLevel = 0; // Simulate sequential unlock
    
    // Check solved status to unlock next
    bool previousSolved = true;

    for (const Challenge &c : challenges) {
        bool locked = !previousSolved;
        if (c.solved) previousSolved = true;
        else previousSolved = false;
        
        // Don't lock the first one ever
        if (c.id == 1) locked = false;

        QWidget *node = createLevelNode(c, locked);
        m_scrollLayout->addWidget(node);
        
        // Staggered Animation Entry
        // Delay: 100ms * sequential index
        node->hide();
        QTimer::singleShot(currentLevel * 100, [node](){
            AnimationHelper::slideInUp(node, 30, 600);
        });
        
        currentLevel++;
    }
    
    m_scrollLayout->addStretch();
}

QWidget* LearnSection::createLevelNode(const Challenge& c, bool locked) {
    QWidget *wrapper = new QWidget;
    wrapper->setFixedSize(200, 160);
    QVBoxLayout *v = new QVBoxLayout(wrapper);
    v->setSpacing(10);
    v->setAlignment(Qt::AlignCenter);

    QPushButton *btn = new QPushButton;
    btn->setFixedSize(80, 80);
    
    QString color = locked ? "#cbd5e1" : "#6366f1"; // Gray vs Indigo
    if (c.solved) color = "#fbbf24"; // Gold
    
    btn->setStyleSheet(QString(
        "QPushButton { "
        "  background-color: %1; "
        "  border-radius: 40px; "
        "  border: 4px solid #334155; " // Darker Ring
        "  color: white; "
        "  font-weight: bold; "
        "  font-size: 24px; "
        "}" // Removed invalid transform
    ).arg(color));
    
    // Icon
    if (locked) btn->setText("🔒");
    else if (c.solved) btn->setText("✅");
    else btn->setText("★");

    connect(btn, &QPushButton::clicked, [this, c, locked](){
        if (!locked) emit startChallenge(c.id);
    });

    QLabel *lbl = new QLabel(c.title);
    lbl->setAlignment(Qt::AlignCenter);
    lbl->setWordWrap(true);
    lbl->setStyleSheet("font-weight: 600; font-size: 14px; color: #94a3b8;"); // Slate-400

    v->addWidget(btn);
    v->addWidget(lbl);

    return wrapper;
}
