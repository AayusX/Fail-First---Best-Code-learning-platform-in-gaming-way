#ifndef ANIMATEDBUTTON_H
#define ANIMATEDBUTTON_H

#include <QPushButton>
#include <QPropertyAnimation>
#include <QGraphicsEffect>

class AnimatedButton : public QPushButton {
    Q_OBJECT
    Q_PROPERTY(qreal scale READ scale WRITE setScale)

public:
    explicit AnimatedButton(const QString &text, QWidget *parent = nullptr) 
        : QPushButton(text, parent), m_scale(1.0) {
        setCursor(Qt::PointingHandCursor);
        // Important for transform
        setStyleSheet("border: none;"); 
    }

    qreal scale() const { return m_scale; }
    void setScale(qreal s) {
        m_scale = s;
        // Apply transform via stylesheet or geometry? 
        // Stylesheet transform is hard to animate smoothly on QWidgets.
        // Better to use geometry resizing or just simple style updates for color.
        // For true scaling, we'd need QGraphicsView, but let's fake it with geometry padding?
        // Actually, let's just animate size slightly?
        // Or simpler: Color brightness animation.
        update(); 
    }

protected:
    void enterEvent(QEnterEvent *event) override {
        QPushButton::enterEvent(event);
        animateScale(1.0, 1.1); // Scale UP
    }

    void leaveEvent(QEvent *event) override {
        QPushButton::leaveEvent(event);
        animateScale(1.1, 1.0); // Scale DOWN
    }
    
    // Custom paint to handle scaling visual
    // QWidget doesn't support built-in scale property easily without glitches.
    // Let's rely on standard QPropertyAnimation of GEOMETRY for "Pop" effect.
    
    void animateScale(qreal start, qreal end) {
        // Simple grow/shrink on hover
        // Note: Changing geometry on hover can cause layout jitter if not careful.
        // Safer approach: Brightness/Shadow animation.
        
        QPropertyAnimation *anim = new QPropertyAnimation(this, "geometry");
        anim->setDuration(100);
        QRect g = geometry();
        int diff = (end > start) ? 4 : -4; 
        if (end > start) {
            anim->setEndValue(g.adjusted(-2, -2, 2, 2));
        } else {
            anim->setEndValue(g.adjusted(2, 2, -2, -2));
        }
        anim->start(QAbstractAnimation::DeleteWhenStopped);
    }

private:
    qreal m_scale;
};

#endif // ANIMATEDBUTTON_H
