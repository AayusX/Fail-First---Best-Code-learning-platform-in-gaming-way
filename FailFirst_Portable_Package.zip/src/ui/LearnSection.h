#ifndef LEARNSECTION_H
#define LEARNSECTION_H

#include <QWidget>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include "database/DatabaseManager.h" // For Challenge struct

class LearnSection : public QWidget {
    Q_OBJECT
public:
    explicit LearnSection(QWidget *parent = nullptr);
    void refresh();

signals:
    void startChallenge(int id);

private:
    void clearLayout();
    void renderPath();
    QWidget* createLevelNode(const Challenge& c, bool locked);

    QVBoxLayout *m_scrollLayout;
};

#endif // LEARNSECTION_H
