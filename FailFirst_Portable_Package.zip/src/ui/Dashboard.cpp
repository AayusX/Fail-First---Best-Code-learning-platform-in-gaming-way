#include "Dashboard.h"
#include "StyleHelper.h"
#include "LearnSection.h"
#include "ChallengeSection.h"
#include "SimpleSections.h"
#include "LoginWindow.h"
#include "LanguageSelection.h"
#include "core/EconomyManager.h"
#include "core/GamificationEngine.h"
#include "NotificationManager.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFrame>
#include "AnimationHelper.h"

Dashboard::Dashboard(QWidget *parent) : QMainWindow(parent) {
    NotificationManager::instance().setParentWidget(this);
    
    // Root Stack Setup
    m_rootStack = new QStackedWidget(this);
    setCentralWidget(m_rootStack);
    
    // 1. Login Screen
    m_loginWindow = new LoginWindow(this);
    m_rootStack->addWidget(m_loginWindow);
    connect(m_loginWindow, &LoginWindow::loginSuccess, this, &Dashboard::onLoginSuccess);
    
    // 2. Language Selection
    m_langSelect = new LanguageSelection(this);
    m_rootStack->addWidget(m_langSelect);
    connect(m_langSelect, &LanguageSelection::languageSelected, this, &Dashboard::onLanguageSelected);
    // 3. Main App (Placeholder for now, initialized on demand or here)
    m_mainAppWidget = new QWidget;
    setupUi(); // This now builds into m_mainAppWidget
    m_rootStack->addWidget(m_mainAppWidget);
    
    resize(1200, 800);
    setStyleSheet(StyleHelper::getMainWindowStyle());
    
    // Start at Login
    m_rootStack->setCurrentWidget(m_loginWindow);
    
    // Connect stats signals
    connect(&EconomyManager::instance(), &EconomyManager::bitsChanged, this, &Dashboard::updateStats);
    connect(&EconomyManager::instance(), &EconomyManager::heartsChanged, this, &Dashboard::updateStats);
    connect(&GamificationEngine::instance(), &GamificationEngine::xpChanged, this, &Dashboard::updateStats);
}

void Dashboard::onLoginSuccess() {
    NotificationManager::instance().showNotification("Welcome Back!", "Let's fix some bugs.", "success");
    showLanguageSelection();
}

void Dashboard::showLanguageSelection() {
    m_rootStack->setCurrentWidget(m_langSelect);
}

void Dashboard::onLanguageSelected(QString lang) {
    // Refresh content based on language?
    // LearnSection needs to know language changed.
    // For now, re-instantiate or refresh.
    loadSections(); // Reload content
    updateStats();
    showMainInterface();
}

void Dashboard::showMainInterface() {
    m_rootStack->setCurrentWidget(m_mainAppWidget);
}

void Dashboard::setupUi() {
    // Builds the Main App Interface into m_mainAppWidget
    
    QHBoxLayout *mainLayout = new QHBoxLayout(m_mainAppWidget);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);
    
    createSidebar();
    mainLayout->addWidget(m_sidebar);
    
    QWidget *rightContainer = new QWidget;
    QVBoxLayout *rightLayout = new QVBoxLayout(rightContainer);
    rightLayout->setContentsMargins(0, 0, 0, 0);
    rightLayout->setSpacing(0);
    
    // Header
    QFrame *headerFrame = new QFrame;
    headerFrame->setStyleSheet("background-color: #1e293b; border-bottom: 1px solid #334155;"); // Dark Header
    headerFrame->setFixedHeight(70);
    QHBoxLayout *headerLayout = new QHBoxLayout(headerFrame);
    
    headerLayout->addStretch();
    
    m_bitsLabel = new QLabel("💎 0");
    m_bitsLabel->setStyleSheet("color: #38bdf8; font-weight: bold; font-size: 16px; margin-right: 20px;"); // Sky Blue
    headerLayout->addWidget(m_bitsLabel);

    m_streakLabel = new QLabel("🔥 0");
    m_streakLabel->setStyleSheet("color: #fb923c; font-weight: bold; font-size: 16px; margin-right: 20px;"); // Orange
    headerLayout->addWidget(m_streakLabel);

    m_heartsLabel = new QLabel("❤️ 5");
    m_heartsLabel->setStyleSheet("color: #f87171; font-weight: bold; font-size: 16px; margin-right: 20px;"); // Red
    headerLayout->addWidget(m_heartsLabel);
    
    m_xpLabel = new QLabel("XP: 0 / Lvl 1");
    m_xpLabel->setStyleSheet("color: #a78bfa; font-weight: bold; font-size: 16px; margin-right: 20px;"); // Purple
    headerLayout->addWidget(m_xpLabel);
    
    rightLayout->addWidget(headerFrame);
    
    m_contentStack = new QStackedWidget;
    // loadSections called later
    rightLayout->addWidget(m_contentStack);
    
    mainLayout->addWidget(rightContainer);
}

void Dashboard::createSidebar() {
    m_sidebar = new QWidget;
    m_sidebar->setFixedWidth(250);
    m_sidebar->setStyleSheet("background-color: #1e293b; border-right: 1px solid #334155;"); // Dark Sidebar
    
    QVBoxLayout *layout = new QVBoxLayout(m_sidebar);
    
    QLabel *logo = new QLabel("Fail{First}");
    logo->setStyleSheet("font-size: 24px; font-weight: 900; color: #818cf8; padding: 20px;"); // Indigo-400 logo
    layout->addWidget(logo);
    
    m_navStats = new QListWidget;
    m_navStats->setStyleSheet(StyleHelper::getSidebarStyle());
    
    m_navStats->addItem(new QListWidgetItem("📘 Learning Path"));
    m_navStats->addItem(new QListWidgetItem("🏆 Leaderboard"));
    m_navStats->addItem(new QListWidgetItem("🛒 Marketplace"));
    m_navStats->addItem(new QListWidgetItem("👤 Profile"));
    
    connect(m_navStats, &QListWidget::itemClicked, this, &Dashboard::onNavClicked);
    
    layout->addWidget(m_navStats);
    
    // Animate Sidebar Entry
    AnimationHelper::slideInUp(m_sidebar, -50, 800);
}

void Dashboard::loadSections() {
    // Clear old
    while(m_contentStack->count() > 0) {
        QWidget *w = m_contentStack->widget(0);
        m_contentStack->removeWidget(w);
        w->deleteLater();
    }

    // 0: Learn
    LearnSection *learn = new LearnSection(this);
    m_learnSection = learn;
    m_contentStack->addWidget(learn);
    connect(learn, &LearnSection::startChallenge, [this](int id){
        // TODO: check type logic (Story vs Challenge)
        ChallengeSection *chall = qobject_cast<ChallengeSection*>(m_challengeSection);
        if(chall) {
            chall->loadChallenge(id);
            m_contentStack->setCurrentWidget(m_challengeSection);
        }
    });

    // 1: Leaderboard
    m_leaderboardSection = new LeaderboardSection(this);
    m_contentStack->addWidget(m_leaderboardSection);
    
    // 2: Shop
    m_shopSection = new ShopSection(this);
    m_contentStack->addWidget(m_shopSection);
    
    // 3: Profile
    m_profileSection = new ProfileSection(this);
    m_contentStack->addWidget(m_profileSection);
    
    // 4: Challenge
    ChallengeSection *challenge = new ChallengeSection(this);
    m_challengeSection = challenge;
    m_contentStack->addWidget(challenge);
    connect(challenge, &ChallengeSection::backToLearn, [this](){
        m_contentStack->setCurrentWidget(m_learnSection);
        static_cast<LearnSection*>(m_learnSection)->refresh();
    });
}

void Dashboard::onNavClicked(QListWidgetItem *item) {
    if(!m_learnSection) return; 
    
    QString txt = item->text();
    if (txt.contains("Learning")) m_contentStack->setCurrentWidget(m_learnSection);
    else if (txt.contains("Leaderboard")) m_contentStack->setCurrentWidget(m_leaderboardSection);
    else if (txt.contains("Marketplace")) m_contentStack->setCurrentWidget(m_shopSection);
    else if (txt.contains("Profile")) m_contentStack->setCurrentWidget(m_profileSection);
}

void Dashboard::updateStats() {
    EconomyManager &eco = EconomyManager::instance();
    m_bitsLabel->setText(QString("💎 %1").arg(eco.bits()));
    m_heartsLabel->setText(QString("❤️ %1").arg(eco.hearts()));
    m_streakLabel->setText(QString("🔥 %1").arg(GamificationEngine::instance().currentStreak()));
    m_xpLabel->setText(QString("XP: %1 / Lvl %2").arg(GamificationEngine::instance().currentXP()).arg(GamificationEngine::instance().currentLevel()));
    
    AnimationHelper::pop(m_bitsLabel);
    AnimationHelper::pop(m_heartsLabel);
    AnimationHelper::pop(m_streakLabel);
    AnimationHelper::pop(m_xpLabel);
}

void Dashboard::resizeEvent(QResizeEvent *event) {
    QMainWindow::resizeEvent(event);
}
