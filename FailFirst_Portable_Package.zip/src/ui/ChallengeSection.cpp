#include "ChallengeSection.h"
#include "StyleHelper.h"
#include "AnimationHelper.h"
#include "core/Validator.h"
#include "core/EconomyManager.h"
#include "core/GamificationEngine.h"
#include "NotificationManager.h"
#include <QButtonGroup>
#include <QCoreApplication>
#include <QHBoxLayout>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMessageBox>
#include <QRadioButton>
#include <QRegularExpression>
#include <QSplitter>
#include <QVBoxLayout>

// --- Syntax Highlighter (Kept Inline for functionality) ---
class CppHighlighter : public QSyntaxHighlighter {
public:
    CppHighlighter(QTextDocument *parent) : QSyntaxHighlighter(parent) {
        HighlightingRule rule;
        keywordFormat.setForeground(QColor("#c678dd"));
        keywordFormat.setFontWeight(QFont::Bold);
        QStringList keywords = { "class", "const", "enum", "explicit", "friend", "inline", "namespace", "operator", "private", "protected", "public", "signals", "slots", "static", "struct", "template", "typedef", "typename", "union", "virtual", "volatile", "int", "char", "double", "float", "bool", "void", "if", "else", "for", "while", "return", "new", "delete", "true", "false", "nullptr" };
        for (const QString &pattern : keywords) {
            rule.pattern = QRegularExpression("\\b" + pattern + "\\b");
            rule.format = keywordFormat;
            highlightingRules.append(rule);
        }
        stringFormat.setForeground(QColor("#98c379"));
        rule.pattern = QRegularExpression("\".*\"");
        rule.format = stringFormat;
        highlightingRules.append(rule);
        commentFormat.setForeground(QColor("#7f848e"));
        rule.pattern = QRegularExpression("//[^\n]*");
        rule.format = commentFormat;
        highlightingRules.append(rule);
    }
protected:
    void highlightBlock(const QString &text) override {
        for (const HighlightingRule &rule : highlightingRules) {
            QRegularExpressionMatchIterator i = rule.pattern.globalMatch(text);
            while (i.hasNext()) {
                QRegularExpressionMatch match = i.next();
                setFormat(match.capturedStart(), match.capturedLength(), rule.format);
            }
        }
    }
private:
    struct HighlightingRule {
        QRegularExpression pattern;
        QTextCharFormat format;
    };
    QVector<HighlightingRule> highlightingRules;
    QTextCharFormat keywordFormat;
    QTextCharFormat stringFormat;
    QTextCharFormat commentFormat;
};

// --- ChallengeSection Implementation ---

ChallengeSection::ChallengeSection(QWidget *parent) : QWidget(parent) {
    m_stack = new QStackedWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(0,0,0,0);
    mainLayout->addWidget(m_stack);
    
    // --- 1. Story Page ---
    m_storyPage = new QWidget;
    QVBoxLayout *storyLayout = new QVBoxLayout(m_storyPage);
    storyLayout->setContentsMargins(40, 40, 40, 40);
    
    m_storyTitle = new QLabel("Story Title");
    m_storyTitle->setStyleSheet("font-size: 32px; font-weight: 900; color: #818cf8; margin-bottom: 20px;"); // Indigo-400
    
    m_storyContent = new QTextBrowser;
    m_storyContent->setStyleSheet("font-size: 18px; line-height: 1.6; color: #cbd5e1; border: none; background: transparent;"); // Slate-300
    
    m_storyNextBtn = new QPushButton("Next Challenge →");
    m_storyNextBtn->setCursor(Qt::PointingHandCursor);
    m_storyNextBtn->setStyleSheet(StyleHelper::getButtonStyle("primary"));
    connect(m_storyNextBtn, &QPushButton::clicked, this, &ChallengeSection::onStoryNext);
    
    storyLayout->addWidget(m_storyTitle);
    storyLayout->addWidget(m_storyContent);
    storyLayout->addWidget(m_storyNextBtn, 0, Qt::AlignRight);
    
    // --- 2. Quiz Page ---
    // --- 2. Quiz Page (Styled as cards in a white container) ---
    m_quizPage = new QWidget;
    m_quizPage->setStyleSheet("background-color: transparent;"); // Inherit main window
    QVBoxLayout *quizRoot = new QVBoxLayout(m_quizPage);
    quizRoot->setContentsMargins(40, 20, 40, 40);
    
    QLabel *quizHeader = new QLabel("Knowledge Check");
    quizHeader->setStyleSheet("font-family: 'Inter'; font-size: 24px; font-weight: 800; color: #94a3b8; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 20px;"); // Slate-400
    
    QWidget *scrollContent = new QWidget;
    scrollContent->setStyleSheet("background-color: transparent;");
    m_quizLayout = new QVBoxLayout(scrollContent);
    m_quizLayout->setSpacing(20);
    
    QScrollArea *scroll = new QScrollArea;
    scroll->setWidget(scrollContent);
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setStyleSheet("background: transparent;");
    
    m_quizSubmitBtn = new QPushButton("Submit Answers");
    m_quizSubmitBtn->setStyleSheet(StyleHelper::getButtonStyle("success"));
    connect(m_quizSubmitBtn, &QPushButton::clicked, this, &ChallengeSection::onQuizSubmit);
    
    quizRoot->addWidget(quizHeader);
    quizRoot->addWidget(scroll);
    quizRoot->addWidget(m_quizSubmitBtn, 0, Qt::AlignRight);
    
    // --- 3. Code Page (Original ChallengeSection Logic) ---
    m_codePage = new QWidget;
    QHBoxLayout *codeLayout = new QHBoxLayout(m_codePage);
    codeLayout->setContentsMargins(20, 20, 20, 20);

    QSplitter *splitter = new QSplitter(Qt::Horizontal);
    
    QWidget *leftPanel = new QWidget;
    QVBoxLayout *leftLayout = new QVBoxLayout(leftPanel);
    
    QPushButton *backBtn = new QPushButton("← Back");
    backBtn->setStyleSheet("border: none; color: #64748b; font-weight: bold; text-align: left;");
    connect(backBtn, &QPushButton::clicked, this, &ChallengeSection::onBackClicked);
    
    m_title = new QLabel("Title");
    m_title->setStyleSheet(StyleHelper::getLabelStyle("header"));
    m_title->setWordWrap(true);
    
    m_desc = new QLabel("Desc");
    m_desc->setStyleSheet(StyleHelper::getLabelStyle("body"));
    m_desc->setWordWrap(true);
    
    m_hintBtn = new QPushButton("💡 Hint (-10 Bits)");
    m_hintBtn->setStyleSheet(StyleHelper::getButtonStyle("primary"));
    connect(m_hintBtn, &QPushButton::clicked, this, &ChallengeSection::onHintClicked);
    
    leftLayout->addWidget(backBtn);
    leftLayout->addWidget(m_title);
    leftLayout->addWidget(m_desc);
    leftLayout->addStretch();
    leftLayout->addWidget(m_hintBtn);

    m_editor = new QPlainTextEdit;
    m_editor->setStyleSheet(StyleHelper::getCodeEditorStyle());
    
    QWidget *rightPanel = new QWidget;
    QVBoxLayout *rightLayout = new QVBoxLayout(rightPanel);
    
    QLabel *outLbl = new QLabel("Output:");
    outLbl->setStyleSheet("font-weight: bold;");
    
    m_output = new QTextBrowser;
    m_output->setStyleSheet("background-color: #0f172a; color: #cbd5e1; border-radius: 8px; font-family: 'JetBrains Mono';");
    
    m_runBtn = new QPushButton("🚀 Run & Validate");
    m_runBtn->setStyleSheet(StyleHelper::getButtonStyle("success"));
    connect(m_runBtn, &QPushButton::clicked, this, &ChallengeSection::onRunClicked);
    
    rightLayout->addWidget(outLbl);
    rightLayout->addWidget(m_output);
    rightLayout->addWidget(m_runBtn);

    splitter->addWidget(leftPanel);
    splitter->addWidget(m_editor);
    splitter->addWidget(rightPanel);
    splitter->setStretchFactor(1, 2); 
    codeLayout->addWidget(splitter);

    // Add pages to stack
    m_stack->addWidget(m_storyPage);
    m_stack->addWidget(m_quizPage);
    m_stack->addWidget(m_codePage);
}

void ChallengeSection::loadChallenge(int id) {
    m_currentChallenge = DatabaseManager::instance().getChallenge(id);
    
    // Setup Story
    m_storyTitle->setText(m_currentChallenge.title);
    
    // Apply Document CSS for Headers (Purple) and Body (Green)
    m_storyContent->document()->setDefaultStyleSheet(StyleHelper::getStoryDocumentCSS());
    
    // Process markdown to HTML with manual syntax highlighting
    QString processed = processStoryText(m_currentChallenge.story_text);
    m_storyContent->setMarkdown(processed); // setMarkdown supports generic markdown
    // Note: setMarkdown might override internal HTML spans for colors if we are not careful.
    // Better to use setHtml if we are pre-processing colors.
    m_storyContent->setHtml(processed); 
    
    // Setup Quiz (Parse JSON)
    QJsonDocument doc = QJsonDocument::fromJson(m_currentChallenge.quiz_data.toUtf8());
    QJsonArray questions = doc.array();
    
    // Clear old quiz
    QLayoutItem *child;
    while ((child = m_quizLayout->takeAt(0)) != 0) {
        if(child->widget()) delete child->widget();
        delete child;
    }
    m_quizAnswers.clear();
    m_quizOptionGroups.clear();
    
    int qIdx = 1;
    for(const auto &val : questions) {
        QJsonObject q = val.toObject();
        QLabel *lbl = new QLabel(q["question"].toString());
        lbl->setStyleSheet("font-family: 'Inter'; font-size: 22px; font-weight: 900; color: #f1f5f9; margin-bottom: 15px; margin-top: 20px;"); // Slate-100
        lbl->setWordWrap(true);
        m_quizLayout->addWidget(lbl);
        
        QJsonArray opts = q["options"].toArray();
        QList<QRadioButton*> group;
        QButtonGroup *btnGroup = new QButtonGroup(this); 
        
        for(int i=0; i<opts.size(); ++i) {
            QRadioButton *rb = new QRadioButton(opts[i].toString());
            rb->setCursor(Qt::PointingHandCursor);
            rb->setStyleSheet(StyleHelper::getQuizOptionStyle());
            m_quizLayout->addWidget(rb);
            group.append(rb);
            btnGroup->addButton(rb, i);
        }
        m_quizOptionGroups.append(group);
        m_quizAnswers.append(q["answer"].toInt());
    }
    m_quizLayout->addStretch();
    
    // Setup Code
    m_title->setText(m_currentChallenge.title);
    m_desc->setText(m_currentChallenge.description);
    m_editor->setPlainText(m_currentChallenge.buggyCode);
    m_output->clear();
    setupHighlighter(m_currentChallenge.language);
    
    // Start at Story
    showStory();
}

void ChallengeSection::showStory() {
    m_stage = LessonStage::Story;
    m_stack->setCurrentWidget(m_storyPage);
    AnimationHelper::fadeIn(m_storyPage);
    AnimationHelper::slideInUp(m_storyContent, 20);
}

void ChallengeSection::onStoryNext() {
    showQuiz();
}

void ChallengeSection::showQuiz() {
    m_stage = LessonStage::Quiz;
    m_stack->setCurrentWidget(m_quizPage);
    AnimationHelper::fadeIn(m_quizPage);
    // Animate quiz items sequentially? For now just main fade
}

void ChallengeSection::onQuizSubmit() {
    // Validate Answers
    int correctCount = 0;
    for(int i=0; i<m_quizAnswers.size(); ++i) {
        int correctIdx = m_quizAnswers[i];
        QList<QRadioButton*> group = m_quizOptionGroups[i];
        if (correctIdx >= 0 && correctIdx < group.size()) {
            if (group[correctIdx]->isChecked()) correctCount++;
        }
    }
    
    if (correctCount == m_quizAnswers.size()) {
        NotificationManager::instance().showNotification("Quiz Perfect!", "Proceeding to Code Challenge...", "success");
        showCode();
    } else {
        NotificationManager::instance().showNotification("Try Again", QString("You got %1/%2 correct.").arg(correctCount).arg(m_quizAnswers.size()), "error");
        AnimationHelper::shake(m_quizSubmitBtn); // Shake button on error
    }
}

void ChallengeSection::showCode() {
    m_stage = LessonStage::Code;
    m_stack->setCurrentWidget(m_codePage);
    AnimationHelper::fadeIn(m_codePage);
}

void ChallengeSection::onRunClicked() {
    m_output->setText("Running...");
    m_runBtn->setEnabled(false);
    QCoreApplication::processEvents();
    
    Validator v;
    QString input = ""; 
    QString expected = "";
    
    QJsonDocument doc = QJsonDocument::fromJson(m_currentChallenge.tests.toUtf8());
    QJsonArray arr = doc.array();
    if (!arr.isEmpty()) {
        QJsonObject t = arr.at(0).toObject();
        input = t["input"].toString();
        expected = t["expected"].toString();
    }
    
    ValidationResult res = v.validate(m_currentChallenge.language, m_editor->toPlainText(), input);
    
    m_runBtn->setEnabled(true);
    
    QString html = "<pre>" + res.output + "</pre>";
    if (!res.error.isEmpty()) {
         html += "<p style='color: red'>" + res.error + "</p>";
    }
    
    bool correct = (res.output.trimmed() == expected.trimmed());
    
    if (correct) {
        html += "<h3 style='color: #22c55e'>✅ PASSED</h3>";
        m_output->setHtml(html);
        
        if (!m_currentChallenge.solved) {
            DatabaseManager::instance().markSolved(m_currentChallenge.id);
            GamificationEngine::instance().addXP(m_currentChallenge.xp);
            DatabaseManager::instance().addBits(100); // Base reward
            GamificationEngine::instance().completeDailyGoal();
            
            // Mega Reward for Hard Levels (XP > 400)
            if (m_currentChallenge.xp >= 400) {
                 DatabaseManager::instance().addBits(500);
                 NotificationManager::instance().showNotification("Lesson Complete!", QString("+%1 XP & +600 Bits!").arg(m_currentChallenge.xp), "success");
            } else {
                NotificationManager::instance().showNotification("Lesson Complete!", QString("+%1 XP & +100 Bits").arg(m_currentChallenge.xp), "success");
            }
            
            // Creative: Confetti Explosion!
            AnimationHelper::confetti(this);

            
            emit backToLearn();
            
        } else {
             NotificationManager::instance().showNotification("Great Job!", "Practice makes perfect!", "success");
        }
        
    } else {
        html += "<h3 style='color: #ef4444'>❌ FAILED</h3>";
        html += "<p>Expected: " + expected + "</p>";
        m_output->setHtml(html);
        
        EconomyManager::instance().loseHeart();
        NotificationManager::instance().showNotification("Bug Found!", "You lost a heart. Debug it!", "error");
        AnimationHelper::shake(m_runBtn); // Shake run button
    }
}

void ChallengeSection::onHintClicked() {
    if (EconomyManager::instance().spendBits(10)) {
        QJsonDocument doc = QJsonDocument::fromJson(m_currentChallenge.hints.toUtf8());
        QJsonArray arr = doc.array();
        QString hint = "No hint available.";
        if (arr.size() > 0) hint = arr.at(0).toString();
        QMessageBox::information(this, "Hint", hint);
    } else {
        NotificationManager::instance().showNotification("Shop", "Not enough bits!", "error");
    }
}

void ChallengeSection::onBackClicked() {
    emit backToLearn();
}

void ChallengeSection::setupHighlighter(const QString& lang) {
    // Delete old highlighter if exists (proper cleanup)
    if (m_highlighter) {
        delete m_highlighter;
        m_highlighter = nullptr;
    }
    
    // Create new highlighter (parented to document for automatic cleanup)
    if (lang == "cpp" || lang == "c") {
        m_highlighter = new CppHighlighter(m_editor->document());
    }
    // Future: Add Python, JavaScript highlighters
}

QString ChallengeSection::processStoryText(const QString &raw) {
    QString md = raw;
    
    // 1. Convert simple Markdown to HTML (Simplified)
    // Actually, let's use Qt's text engine to do the heavy lifting for layout,
    // but syntax highlighting in markdown blocks is hard.
    // Strategy: We will manually replace ```cpp ... ``` blocks with HTML tables or pre blocks
    // containing COLORIZED spans.
    
    QRegularExpression codeBlock("```cpp(.*?)```", QRegularExpression::DotMatchesEverythingOption);
    QRegularExpressionMatchIterator i = codeBlock.globalMatch(md);
    
    while (i.hasNext()) {
        QRegularExpressionMatch match = i.next();
        QString content = match.captured(1).trimmed();
        
        // Colorize Keywords
        content.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); // Escape HTML
        
        // Simple Replacements for Syntax Highlighting
        // Keywords -> Purple
        QStringList keywords = { "int ", "void ", "return ", "if ", "else ", "class ", "public:", "private:", "include ", "std::", "cout", "endl" };
        for (const QString &k : keywords) {
            content.replace(k, QString("<span style='color: #c678dd; font-weight: bold;'>%1</span>").arg(k));
        }
        
        // Strings -> Green
        QRegularExpression strReg("\".*?\"");
        content.replace(strReg, "<span style='color: #98c379;'>\\0</span>");
        
        // Comments -> Gray
        QRegularExpression comReg("//.*");
        content.replace(comReg, "<span style='color: #7f848e;'>\\0</span>");

        // Wrap in styled div
        QString htmlBlock = QString("<pre style='background-color: #1e1e2e; color: #abb2bf; padding: 15px; border-radius: 8px;'>%1</pre>").arg(content);
        
        // Replace in original string
        md.replace(match.captured(0), htmlBlock);
    }
    
    // Convert remaining basic markdown Headers to HTML for our CSS to catch
    // # Header -> <h1>Header</h1>
    md.replace(QRegularExpression("^# (.*)$", QRegularExpression::MultilineOption), "<h1>\\1</h1>");
    md.replace(QRegularExpression("^## (.*)$", QRegularExpression::MultilineOption), "<h2>\\1</h2>");
    md.replace(QRegularExpression("^### (.*)$", QRegularExpression::MultilineOption), "<h3>\\1</h3>");
    
    // Newlines to <br> or <p>
    md.replace("\n", "<br>");
    
    return md;
}
