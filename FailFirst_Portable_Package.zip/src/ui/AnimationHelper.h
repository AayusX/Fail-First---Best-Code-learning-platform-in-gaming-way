#ifndef ANIMATIONHELPER_H
#define ANIMATIONHELPER_H

#include <QWidget>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>
#include <QSequentialAnimationGroup>
#include <QParallelAnimationGroup>

class AnimationHelper {
public:
    // Fade in a widget nicely
    static void fadeIn(QWidget *widget, int duration = 500) {
        if (!widget) return;
        QGraphicsOpacityEffect *effect = new QGraphicsOpacityEffect(widget);
        widget->setGraphicsEffect(effect);
        
        QPropertyAnimation *anim = new QPropertyAnimation(effect, "opacity");
        anim->setDuration(duration);
        anim->setStartValue(0.0);
        anim->setEndValue(1.0);
        anim->setEasingCurve(QEasingCurve::OutQuad);
        anim->start(QAbstractAnimation::DeleteWhenStopped);
    }

    // Slide widget up (good for entering cards)
    static void slideInUp(QWidget *widget, int offset = 50, int duration = 600) {
        if (!widget) return;
        QRect end = widget->geometry();
        QRect start = end.adjusted(0, offset, 0, offset);
        
        widget->setGeometry(start);
        widget->setVisible(true);
        
        QPropertyAnimation *anim = new QPropertyAnimation(widget, "geometry");
        anim->setDuration(duration);
        anim->setStartValue(start);
        anim->setEndValue(end);
        anim->setEasingCurve(QEasingCurve::OutBack); // Bouncy effect
        anim->start(QAbstractAnimation::DeleteWhenStopped);
        
        // Combine with fade for better look
        fadeIn(widget, duration);
    }
    
    // Shake effect for wrong answers
    static void shake(QWidget *widget) {
        if (!widget) return;
        QPropertyAnimation *anim = new QPropertyAnimation(widget, "pos");
        anim->setDuration(500);
        anim->setLoopCount(1);
        
        QPoint pos = widget->pos();
        anim->setKeyValueAt(0, pos);
        anim->setKeyValueAt(0.1, pos + QPoint(10, 0));
        anim->setKeyValueAt(0.2, pos + QPoint(-10, 0));
        anim->setKeyValueAt(0.3, pos + QPoint(10, 0));
        anim->setKeyValueAt(0.4, pos + QPoint(-10, 0));
        anim->setKeyValueAt(0.5, pos + QPoint(5, 0));
        anim->setKeyValueAt(0.6, pos + QPoint(-5, 0));
        anim->setKeyValueAt(1.0, pos);
        
        anim->start(QAbstractAnimation::DeleteWhenStopped);
    }
    
    // Pop effect for labels (e.g. +XP)
    static void pop(QWidget *widget) {
        if (!widget) return;
        QRect original = widget->geometry();
        QRect scaled = original.adjusted(-5, -5, 5, 5);
        
        QSequentialAnimationGroup *group = new QSequentialAnimationGroup(widget);
        
        QPropertyAnimation *grow = new QPropertyAnimation(widget, "geometry");
        grow->setDuration(100);
        grow->setStartValue(original);
        grow->setEndValue(scaled);
        
        QPropertyAnimation *shrink = new QPropertyAnimation(widget, "geometry");
        shrink->setDuration(100);
        shrink->setStartValue(scaled);
        shrink->setEndValue(original);
        
        group->addAnimation(grow);
        group->addAnimation(shrink);
        group->start(QAbstractAnimation::DeleteWhenStopped);
    }

    // --- Creative: Particle Explosion (Confetti) ---
    static void confetti(QWidget *parent) {
        if (!parent) return;
        
        for (int i = 0; i < 30; i++) {
            QLabel *p = new QLabel(parent);
            p->resize(8, 8);
            
            // Random Color
            QStringList colors = {"#f472b6", "#fbbf24", "#60a5fa", "#a78bfa", "#34d399"}; // Pink, Gold, Blue, Purple, Green
            QString color = colors[rand() % colors.size()];
            p->setStyleSheet(QString("background-color: %1; border-radius: 4px;").arg(color));
            
            // Random Start Pos (Center-ish)
            int startX = parent->width() / 2 + (rand() % 40 - 20);
            int startY = parent->height() / 2 + (rand() % 40 - 20);
            p->move(startX, startY);
            p->show();
            
            // Random Trajectory
            int endX = startX + (rand() % 300 - 150);
            int endY = startY + (rand() % 300 - 150);
            
            QParallelAnimationGroup *group = new QParallelAnimationGroup(p);
            
            // Move
            QPropertyAnimation *move = new QPropertyAnimation(p, "pos");
            move->setDuration(800 + (rand() % 400));
            move->setStartValue(QPoint(startX, startY));
            move->setEndValue(QPoint(endX, endY));
            move->setEasingCurve(QEasingCurve::OutQuad);
            
            // Fade Out
            QGraphicsOpacityEffect *eff = new QGraphicsOpacityEffect(p);
            p->setGraphicsEffect(eff);
            QPropertyAnimation *fade = new QPropertyAnimation(eff, "opacity");
            fade->setDuration(800);
            fade->setStartValue(1.0);
            fade->setEndValue(0.0);
            
            group->addAnimation(move);
            group->addAnimation(fade);
            
            // Cleanup particle after animation
            QObject::connect(group, &QAbstractAnimation::finished, [p](){
                delete p;
            });
            
            group->start(QAbstractAnimation::DeleteWhenStopped);
        }
    }
};

#endif // ANIMATIONHELPER_H
