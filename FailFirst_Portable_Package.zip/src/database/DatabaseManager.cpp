#include "DatabaseManager.h"
#include <QCoreApplication>
#include <QDateTime>
#include <QDebug>

DatabaseManager& DatabaseManager::instance() {
    static DatabaseManager instance;
    return instance;
}

DatabaseManager::DatabaseManager() : m_currentUserId(-1) {}

bool DatabaseManager::init() {
    // PORTABLE DATABASE: Store next to .exe for true portability
    QString appDir = QCoreApplication::applicationDirPath();
    QString dataDir = appDir + "/FailFirstData";
    QDir().mkpath(dataDir);
    QString dbPath = dataDir + "/failfirst.db";
    
    qDebug() << "Database location:" << dbPath;
    
    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName(dbPath);
    
    if (!m_db.open()) {
        qWarning() << "Failed to open database:" << m_db.lastError().text();
        return false;
    }
    
    // Performance optimizations
    QSqlQuery("PRAGMA synchronous = NORMAL");
    QSqlQuery("PRAGMA journal_mode = WAL");
    QSqlQuery("PRAGMA cache_size = 10000");
    
    createTables();
    loadInitialContent();
    return true;
}

void DatabaseManager::createTables() {
    QSqlQuery query;
    // Users: Added username, password, current_language
    query.exec("CREATE TABLE IF NOT EXISTS users ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT, "
               "username TEXT UNIQUE, "
               "password TEXT, " 
               "avatar TEXT DEFAULT '👨‍💻', "  // New: Avatar emoji
               "xp INTEGER DEFAULT 0, "
               "bits INTEGER DEFAULT 0, "
               "streak INTEGER DEFAULT 0, "
               "current_language TEXT, "
               "last_active TEXT)");
               
    // Challenges: Updated for Multi-Stage Lessons (Story -> Quiz -> Code)
    query.exec("CREATE TABLE IF NOT EXISTS challenges ("
               "id INTEGER PRIMARY KEY, "
               "title TEXT, "
               "type TEXT DEFAULT 'lesson_unit', " 
               "language TEXT, "
               "difficulty TEXT, "
               "description TEXT, " // Short desc for menu
               "story_text TEXT, "   // Stage 1: Narrative
               "quiz_data TEXT, "    // Stage 2: JSON Array of MCQs
               "buggyCode TEXT, "    // Stage 3: Code
               "solutionCode TEXT, "
               "tests TEXT, "
               "hints TEXT, "
               "xp INTEGER)");
               
    // Migration helper: If table exists but misses columns, we might need to recreate or alter.
    // For this dev session, since we reset DB often, checking column existence is good practice 
    // but simply relying on force update (reset) as per user request is easiest.
    // User asked to reset, so we are on v4. Let's bump to v5 to be safe and ensure clean schema.
               
    query.exec("CREATE TABLE IF NOT EXISTS solved (user_id INTEGER, challenge_id INTEGER, PRIMARY KEY(user_id, challenge_id))");
    query.exec("CREATE TABLE IF NOT EXISTS items (user_id INTEGER, item_id TEXT, PRIMARY KEY(user_id, item_id))");
}

bool DatabaseManager::login(const QString& username, const QString& password) {
    QSqlQuery query;
    query.prepare("SELECT id, password, xp, bits, streak FROM users WHERE username = ?");
    query.addBindValue(username);
    
    if (!query.exec()) {
        qWarning() << "Login query failed:" << query.lastError().text();
        return false;
    }
    
    if (query.next()) {
        QString storedHash = query.value("password").toString();
        
        // Verify password hash
        if (verifyPassword(password, storedHash)) {
            m_currentUserId = query.value("id").toInt();
            emit userChanged();
            return true;
        }
    }
    return false;
}

bool DatabaseManager::registerUser(const QString& username, const QString& password) {
    // Hash password before storing
    QString hashedPassword = hashPassword(password);
    
    QSqlQuery query;
    query.prepare("INSERT INTO users (username, password, xp, bits, streak) VALUES (?, ?, 0, 100, 0)");
    query.addBindValue(username);
    query.addBindValue(hashedPassword);
    
    if (query.exec()) {
        m_currentUserId = query.lastInsertId().toInt();
        emit userChanged();
        return true;
    }
    return false;
}

int DatabaseManager::currentUserId() const {
    return m_currentUserId;
}

QString DatabaseManager::getCurrentUsername() {
    if (m_currentUserId == -1) return "";
    QSqlQuery query;
    query.prepare("SELECT username FROM users WHERE id = ?");
    query.addBindValue(m_currentUserId);
    query.exec();
    if (query.next()) return query.value(0).toString();
    return "";
}

void DatabaseManager::setLanguage(const QString& lang) {
    if (m_currentUserId == -1) return;
    QSqlQuery query;
    query.prepare("UPDATE users SET current_language = ? WHERE id = ?");
    query.addBindValue(lang);
    query.addBindValue(m_currentUserId);
    query.exec();
}

QString DatabaseManager::getLanguage() {
    if (m_currentUserId == -1) return "";
    QSqlQuery query;
    query.prepare("SELECT current_language FROM users WHERE id = ?");
    query.addBindValue(m_currentUserId);
    query.exec();
    if (query.next()) return query.value(0).toString();
    return "";
}

QString DatabaseManager::getAvatar() {
    if (m_currentUserId == -1) return "👨‍💻";
    QSqlQuery query;
    query.prepare("SELECT avatar FROM users WHERE id = ?");
    query.addBindValue(m_currentUserId);
    query.exec();
    if (query.next()) return query.value(0).toString();
    return "👨‍💻";
}

void DatabaseManager::setAvatar(const QString& avatar) {
    if (m_currentUserId == -1) return;
    QSqlQuery query;
    query.prepare("UPDATE users SET avatar = ? WHERE id = ?");
    query.addBindValue(avatar);
    query.addBindValue(m_currentUserId);
    query.exec();
}

// ... Rest of loadInitialContent ...

void DatabaseManager::loadInitialContent() {
    QSqlQuery checkQuery;
    checkQuery.exec("SELECT count(*) FROM challenges");
    if (checkQuery.next() && checkQuery.value(0).toInt() > 0) return; // Already loaded

    // Load C++ challenges
    loadChallengesFromFile(":/resources/challenges.json");
    
    // Load C challenges
    loadChallengesFromFile(":/resources/challenges_c.json");
    
    // Load Java challenges
    loadChallengesFromFile(":/resources/challenges_java.json");
}

void DatabaseManager::loadChallengesFromFile(const QString& filePath) {
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Could not open" << filePath;
        return;
    }

    QByteArray data = file.readAll();
    file.close();
    
    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isArray()) {
        qWarning() << "Invalid JSON format in" << filePath;
        return;
    }
    
    QJsonArray array = doc.array();

    m_db.transaction();
    QSqlQuery query;
    query.prepare("INSERT INTO challenges (id, title, language, difficulty, description, story_text, quiz_data, buggyCode, solutionCode, tests, hints, xp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    for (const auto& val : array) {
        QJsonObject obj = val.toObject();
        query.addBindValue(obj["id"].toInt());
        query.addBindValue(obj["title"].toString());
        query.addBindValue(obj["language"].toString());
        query.addBindValue(obj["difficulty"].toString());
        query.addBindValue(obj["description"].toString());
        query.addBindValue(obj["story_text"].toString());
        query.addBindValue(obj["quiz_data"].toString());
        query.addBindValue(obj["buggy_code"].toString());
        query.addBindValue(obj["solution_code"].toString());
        query.addBindValue(QJsonDocument(obj["tests"].toArray()).toJson(QJsonDocument::Compact));
        query.addBindValue(QJsonDocument(obj["hints"].toArray()).toJson(QJsonDocument::Compact));
        query.addBindValue(obj["xp"].toInt());
        
        if (!query.exec()) {
            qWarning() << "Failed to insert challenge" << obj["id"].toInt() << ":" << query.lastError().text();
        }
    }
    m_db.commit();
    
    qDebug() << "Loaded" << array.size() << "challenges from" << filePath;
}

QList<Challenge> DatabaseManager::getAllChallenges() {
    QList<Challenge> list;
    QString lang = getLanguage();
    
    // Filter by language - simpler logic
    QSqlQuery query;
    if (!lang.isEmpty()) {
        query.prepare("SELECT * FROM challenges WHERE language = ?");
        query.addBindValue(lang);
    } else {
        query.prepare("SELECT * FROM challenges");
    }
    
    if (!query.exec()) {
        qWarning() << "getAllChallenges query failed:" << query.lastError().text();
        return list;
    }

    while (query.next()) {
        Challenge c;
        c.id = query.value("id").toInt();
        c.title = query.value("title").toString();
        c.language = query.value("language").toString();
        c.difficulty = query.value("difficulty").toString();
        c.description = query.value("description").toString();
        
        // CRITICAL FIX: Add missing fields!
        c.story_text = query.value("story_text").toString();
        c.quiz_data = query.value("quiz_data").toString();
        
        c.buggyCode = query.value("buggyCode").toString();
        c.solutionCode = query.value("solutionCode").toString();
        c.tests = query.value("tests").toString();
        c.hints = query.value("hints").toString();
        c.xp = query.value("xp").toInt();
        
        // Check if solved
        QSqlQuery solvedQuery;
        solvedQuery.prepare("SELECT count(*) FROM solved WHERE challenge_id = ? AND user_id = ?");
        solvedQuery.addBindValue(c.id);
        solvedQuery.addBindValue(m_currentUserId);
        solvedQuery.exec();
        if (solvedQuery.next()) c.solved = solvedQuery.value(0).toInt() > 0;
        
        list.append(c);
    }
    
    qDebug() << "Loaded" << list.size() << "challenges for language:" << lang;
    return list;
}

Challenge DatabaseManager::getChallenge(int id) {
    QSqlQuery query;
    query.prepare("SELECT * FROM challenges WHERE id = ?");
    query.addBindValue(id);
    
    if (!query.exec()) {
        qWarning() << "getChallenge query failed:" << query.lastError().text();
        return Challenge();
    }
    
    if (query.next()) {
        Challenge c;
        c.id = query.value("id").toInt();
        c.title = query.value("title").toString();
        c.language = query.value("language").toString();
        c.difficulty = query.value("difficulty").toString();
        c.description = query.value("description").toString();
        
        // CRITICAL FIX: Add missing fields!
        c.story_text = query.value("story_text").toString();
        c.quiz_data = query.value("quiz_data").toString();
        
        c.buggyCode = query.value("buggyCode").toString();
        c.solutionCode = query.value("solutionCode").toString();
        c.tests = query.value("tests").toString();
        c.hints = query.value("hints").toString();
        c.xp = query.value("xp").toInt();
        
        qDebug() << "Loaded challenge:" << c.title << "with story_text length:" << c.story_text.length();
        return c;
    }
    return Challenge();
}

bool DatabaseManager::markSolved(int challengeId) {
    if (m_currentUserId == -1) return false;
    QSqlQuery query;
    query.prepare("INSERT OR IGNORE INTO solved (user_id, challenge_id) VALUES (?, ?)");
    query.addBindValue(m_currentUserId);
    query.addBindValue(challengeId);
    return query.exec();
}

int DatabaseManager::getXP() {
    if (m_currentUserId == -1) return 0;
    QSqlQuery query;
    query.prepare("SELECT xp FROM users WHERE id=?");
    query.addBindValue(m_currentUserId);
    query.exec();
    if (query.next()) return query.value(0).toInt();
    return 0;
}

void DatabaseManager::addXP(int amount) {
    if (m_currentUserId == -1) return;
    QSqlQuery query;
    query.prepare("UPDATE users SET xp = xp + ? WHERE id=?");
    query.addBindValue(amount);
    query.addBindValue(m_currentUserId);
    query.exec();
}

int DatabaseManager::getBits() {
    if (m_currentUserId == -1) return 0;
    QSqlQuery query;
    query.prepare("SELECT bits FROM users WHERE id=?");
    query.addBindValue(m_currentUserId);
    query.exec();
    if (query.next()) return query.value(0).toInt();
    return 0;
}

void DatabaseManager::addBits(int amount) {
    if (m_currentUserId == -1) return;
    QSqlQuery query;
    query.prepare("UPDATE users SET bits = bits + ? WHERE id=?");
    query.addBindValue(amount);
    query.addBindValue(m_currentUserId);
    query.exec();
}

bool DatabaseManager::spendBits(int amount) {
    if (getBits() < amount) return false;
    QSqlQuery query;
    query.prepare("UPDATE users SET bits = bits - ? WHERE id=?");
    query.addBindValue(amount);
    query.addBindValue(m_currentUserId);
    return query.exec();
}

int DatabaseManager::getStreak() {
    if (m_currentUserId == -1) return 0;
    QSqlQuery query;
    query.prepare("SELECT streak FROM users WHERE id=?");
    query.addBindValue(m_currentUserId);
    query.exec();
    if (query.next()) return query.value(0).toInt();
    return 0;
}

void DatabaseManager::incrementStreak() {
    if (m_currentUserId == -1) return;
    QSqlQuery query;
    query.prepare("UPDATE users SET streak = streak + 1 WHERE id=?");
    query.addBindValue(m_currentUserId);
    query.exec();
}

bool DatabaseManager::hasItem(const QString& itemId) {
    if (m_currentUserId == -1) return false;
    QSqlQuery query;
    query.prepare("SELECT count(*) FROM items WHERE item_id = ? AND user_id = ?");
    query.addBindValue(itemId);
    query.addBindValue(m_currentUserId);
    query.exec();
    return query.next() && query.value(0).toInt() > 0;
}

void DatabaseManager::addItem(const QString& itemId) {
    if (m_currentUserId == -1) return;
    QSqlQuery query;
    query.prepare("INSERT OR IGNORE INTO items (user_id, item_id) VALUES (?, ?)");
    query.addBindValue(m_currentUserId);
    query.addBindValue(itemId);
    query.exec();
}

// --- Password Security Functions ---

QString DatabaseManager::hashPassword(const QString& password) {
    // Generate random salt (16 bytes)
    QByteArray salt = generateSalt();
    
    // Hash password with salt using SHA-256
    QCryptographicHash hash(QCryptographicHash::Sha256);
    hash.addData(salt);
    hash.addData(password.toUtf8());
    
    QByteArray hashedPassword = hash.result();
    
    // Store as: salt$hash (both base64 encoded)
    return salt.toBase64() + "$" + hashedPassword.toBase64();
}

bool DatabaseManager::verifyPassword(const QString& password, const QString& storedHash) {
    // Split stored hash into salt and hash
    QStringList parts = storedHash.split("$");
    if (parts.size() != 2) {
        qWarning() << "Invalid password hash format";
        return false;
    }
    
    QByteArray salt = QByteArray::fromBase64(parts[0].toUtf8());
    QByteArray storedPasswordHash = QByteArray::fromBase64(parts[1].toUtf8());
    
    // Hash the provided password with the stored salt
    QCryptographicHash hash(QCryptographicHash::Sha256);
    hash.addData(salt);
    hash.addData(password.toUtf8());
    
    QByteArray computedHash = hash.result();
    
    // Constant-time comparison to prevent timing attacks
    return computedHash == storedPasswordHash;
}

QByteArray DatabaseManager::generateSalt() {
    QByteArray salt;
    salt.resize(16);
    
    // Use QRandomGenerator for cryptographically secure random bytes (Qt 5.10+)
    for (int i = 0; i < 16; ++i) {
        salt[i] = static_cast<char>(QRandomGenerator::global()->bounded(256));
    }
    
    return salt;
}
