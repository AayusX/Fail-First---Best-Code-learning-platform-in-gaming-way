#include <QApplication>
#include <QFontDatabase>
#include "ui/Dashboard.h"
#include "database/DatabaseManager.h"
#include "core/EconomyManager.h"

void loadFonts() {
    // Attempt to load embedded fonts if available, otherwise rely on system
    // In a real scenario: QFontDatabase::addApplicationFont(":/resources/fonts/Inter-Regular.ttf");
}

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    
    app.setOrganizationName("FailFirstEdu");
    app.setApplicationName("FailFirst");
    
    // Set application icon (shows in taskbar, window title, .exe file)
    app.setWindowIcon(QIcon(":/resources/icons/app_icon.png"));
    
    // Init Database
    if (!DatabaseManager::instance().init()) {
        qWarning() << "Failed to initialize database!";
        // Continue anyway for UI testing logic if needed, or exit
    }
    
    // Init Singletons
    EconomyManager::instance(); 
    
    Dashboard w;
    w.show();
    
    return app.exec();
}
