#include "EconomyManager.h"
#include <QTimer>

EconomyManager& EconomyManager::instance() {
    static EconomyManager instance;
    return instance;
}

EconomyManager::EconomyManager() : m_hearts(5) {
    // In a real app, hearts would be persisted.
}

int EconomyManager::bits() const {
    return DatabaseManager::instance().getBits();
}

int EconomyManager::hearts() const {
    return m_hearts;
}

QString EconomyManager::nextHeartTime() const {
    return "25:00"; // Dummy implementation for now
}

void EconomyManager::earnBits(int amount) {
    DatabaseManager::instance().addBits(amount);
    emit bitsChanged();
}

bool EconomyManager::spendBits(int amount) {
    if (DatabaseManager::instance().spendBits(amount)) {
        emit bitsChanged();
        return true;
    }
    emit purchaseFailed("Not enough bits!");
    return false;
}

void EconomyManager::loseHeart() {
    if (m_hearts > 0) {
        m_hearts--;
        emit heartsChanged();
    }
}

void EconomyManager::refillHearts() {
    m_hearts = 5;
    emit heartsChanged();
}

bool EconomyManager::purchaseItem(const QString& itemId, int cost) {
    if (DatabaseManager::instance().hasItem(itemId)) {
        emit purchaseFailed("Already owned!");
        return false;
    }
    
    if (spendBits(cost)) {
        DatabaseManager::instance().addItem(itemId);
        emit purchaseSuccess(itemId);
        
        if (itemId == "health_potion") refillHearts();
        
        return true;
    }
    return false;
}
