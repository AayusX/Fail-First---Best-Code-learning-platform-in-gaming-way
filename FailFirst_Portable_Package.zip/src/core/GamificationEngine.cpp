#include "GamificationEngine.h"

GamificationEngine& GamificationEngine::instance() {
    static GamificationEngine instance;
    return instance;
}

GamificationEngine::GamificationEngine() {}

int GamificationEngine::currentXP() {
    return DatabaseManager::instance().getXP();
}

int GamificationEngine::currentLevel() {
    return calculateLevel(currentXP());
}

int GamificationEngine::currentStreak() {
    return DatabaseManager::instance().getStreak();
}

void GamificationEngine::addXP(int amount) {
    int oldLevel = currentLevel();
    DatabaseManager::instance().addXP(amount);
    emit xpChanged(currentXP());
    
    int newLevel = currentLevel();
    if (newLevel > oldLevel) {
        emit levelChanged(newLevel);
        emit levelUp(newLevel);
    }
}

void GamificationEngine::completeDailyGoal() {
    // Logic to check if already completed today would rely on persistent "Last Active" date
    DatabaseManager::instance().incrementStreak();
    emit streakChanged(currentStreak());
}

double GamificationEngine::getLevelProgress() {
    int xp = currentXP();
    int leveXPStart = (currentLevel() - 1) * 1000; // Simplified logic
    int nextLevelXP = currentLevel() * 1000;
    return (double)(xp - leveXPStart) / (nextLevelXP - leveXPStart);
}

int GamificationEngine::calculateLevel(int xp) {
    return (xp / 1000) + 1; // Simple linear scaling for demo
}
