#include "CompilerManager.h"
#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QProcess>
#include <QDebug>

CompilerManager& CompilerManager::instance() {
    static CompilerManager instance;
    return instance;
}

CompilerManager::CompilerManager() {
    // Set portable directory relative to executable
    m_portableDir = QCoreApplication::applicationDirPath() + "/portable";
    detectCompilers();
}

void CompilerManager::detectCompilers() {
    if (m_initialized) return;
    
    qDebug() << "CompilerManager: Detecting available compilers...";
    qDebug() << "Portable directory:" << m_portableDir;
    
    // --- C++ Compiler ---
    // Priority: Portable TCC > System g++ > System clang++
    QString cppCompiler = findPortableCompiler("tcc");
    if (cppCompiler.isEmpty()) {
        cppCompiler = findSystemCompiler("g++");
    }
    if (cppCompiler.isEmpty()) {
        cppCompiler = findSystemCompiler("clang++");
    }
    if (!cppCompiler.isEmpty()) {
        m_compilerPaths["cpp"] = cppCompiler;
        qDebug() << "C++ compiler found:" << cppCompiler;
    }
    
    // --- C Compiler ---
    // Priority: Portable TCC > System gcc > System clang
    QString cCompiler = findPortableCompiler("tcc");
    if (cCompiler.isEmpty()) {
        cCompiler = findSystemCompiler("gcc");
    }
    if (cCompiler.isEmpty()) {
        cCompiler = findSystemCompiler("clang");
    }
    if (!cCompiler.isEmpty()) {
        m_compilerPaths["c"] = cCompiler;
        qDebug() << "C compiler found:" << cCompiler;
    }
    
    // --- Python ---
    // Priority: Portable > System
    QString portablePython = findPortableCompiler("python/python.exe"); // Windows portable
    if (portablePython.isEmpty()) portablePython = findPortableCompiler("python/bin/python3"); // Linux portable structure
    
    QString pythonPath = portablePython; 
    if (pythonPath.isEmpty()) pythonPath = findSystemCompiler("python3");
    if (pythonPath.isEmpty()) pythonPath = findSystemCompiler("python");
    
    if (!pythonPath.isEmpty()) {
        m_compilerPaths["python"] = pythonPath;
        m_runtimePaths["python"] = pythonPath;
        qDebug() << "Python found:" << pythonPath;
    }
    
    // --- Java ---
    // Priority: Portable > System
    QString portableJavac = findPortableCompiler("java/bin/javac.exe");
    QString portableJava = findPortableCompiler("java/bin/java.exe");
    
    QString javacPath = !portableJavac.isEmpty() ? portableJavac : findSystemCompiler("javac");
    QString javaPath = !portableJava.isEmpty() ? portableJava : findSystemCompiler("java");
    
    if (!javacPath.isEmpty() && !javaPath.isEmpty()) {
        m_compilerPaths["java"] = javacPath;
        m_runtimePaths["java"] = javaPath;
        qDebug() << "Java found:" << javacPath;
    }
    
    m_initialized = true;
    qDebug() << "CompilerManager: Detection complete. Available:" << m_compilerPaths.keys();
}

QString CompilerManager::findPortableCompiler(const QString& name) {
    // Check for portable compiler in app directory
    QStringList possiblePaths;
    
#ifdef Q_OS_WIN
    // Windows paths
    possiblePaths << m_portableDir + "/tcc/tcc.exe"
                  << m_portableDir + "/" + name
                  << m_portableDir + "/mingw/bin/g++.exe"
                  << m_portableDir + "/mingw/bin/gcc.exe";
#else
    // Linux/Mac paths
    possiblePaths << m_portableDir + "/tcc/tcc"
                  << m_portableDir + "/" + name
                  << m_portableDir + "/bin/" + name;
#endif
    
    for (const QString& path : possiblePaths) {
        if (path.contains(name, Qt::CaseInsensitive)) {
            QFileInfo info(path);
            if (info.exists() && info.isExecutable()) {
                return path;
            }
        }
    }
    
    return QString();
}

QString CompilerManager::findSystemCompiler(const QString& name) {
    // Use QProcess to find compiler in system PATH
    QProcess which;
    
#ifdef Q_OS_WIN
    which.start("where", {name});
#else
    which.start("which", {name});
#endif
    
    if (!which.waitForFinished(2000)) {
        return QString();
    }
    
    if (which.exitCode() != 0) {
        return QString();
    }
    
    QString path = QString::fromUtf8(which.readAllStandardOutput()).trimmed();
    
    // Handle multiple results (take first line)
    if (path.contains('\n')) {
        path = path.split('\n').first().trimmed();
    }
    
    // Verify the compiler works
    if (!path.isEmpty() && testCompiler(path)) {
        return path;
    }
    
    return QString();
}

bool CompilerManager::testCompiler(const QString& path) {
    QProcess test;
    test.start(path, {"--version"});
    
    if (!test.waitForFinished(3000)) {
        return false;
    }
    
    return test.exitCode() == 0;
}

QString CompilerManager::getCompilerPath(const QString& language) {
    if (!m_initialized) {
        detectCompilers();
    }
    return m_compilerPaths.value(language);
}

QStringList CompilerManager::getCompilerArgs(const QString& language) {
    QStringList args;
    
    QString compiler = m_compilerPaths.value(language);
    bool isTcc = compiler.contains("tcc", Qt::CaseInsensitive);
    
    if (language == "cpp") {
        if (isTcc) {
            // TCC doesn't support full C++17, use C mode for basic code
            args << "-run";  // TCC can run directly without separate compile step
        } else {
            args << "-std=c++17";
        }
    } else if (language == "c") {
        if (isTcc) {
            // TCC native mode
        } else {
            args << "-std=c11";
        }
    }
    
    return args;
}

bool CompilerManager::isCompilerAvailable(const QString& language) {
    if (!m_initialized) {
        detectCompilers();
    }
    return m_compilerPaths.contains(language) && !m_compilerPaths[language].isEmpty();
}

QString CompilerManager::getUnavailableMessage(const QString& language) {
    if (language == "cpp" || language == "c") {
        return QString(
            "⚠️ C/C++ Compiler Not Found\n\n"
            "To run code challenges, please install a compiler:\n\n"
            "• Windows: Install MinGW-w64 from https://winlibs.com\n"
            "• Linux: Run 'sudo apt install g++' or equivalent\n"
            "• macOS: Run 'xcode-select --install'\n\n"
            "Or place TCC in the 'portable/' folder next to this app."
        );
    } else if (language == "python") {
        return QString(
            "⚠️ Python Not Found\n\n"
            "To run Python challenges, please install Python 3:\n\n"
            "• Windows: Download from https://python.org\n"
            "• Linux: Run 'sudo apt install python3'\n"
            "• macOS: Run 'brew install python3'"
        );
    } else if (language == "java") {
        return QString(
            "⚠️ Java Not Found\n\n"
            "To run Java challenges, please install JDK 11+:\n\n"
            "• Download from https://adoptium.net\n"
            "• Or run 'sudo apt install openjdk-17-jdk' on Linux"
        );
    }
    
    return "Unsupported language: " + language;
}

QString CompilerManager::getRuntimePath(const QString& language) {
    if (!m_initialized) {
        detectCompilers();
    }
    return m_runtimePaths.value(language);
}

bool CompilerManager::isRuntimeAvailable(const QString& language) {
    if (!m_initialized) {
        detectCompilers();
    }
    return m_runtimePaths.contains(language) && !m_runtimePaths[language].isEmpty();
}
